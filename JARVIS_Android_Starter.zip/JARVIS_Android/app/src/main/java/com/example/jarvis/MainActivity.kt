package com.example.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF030914)
private val Cyan = Color(0xFF22C8FF)
private val Muted = Color(0xFF8CCFEA)
private val Panel = Color(0xFF071B2B)

data class ChatMessage(val fromUser: Boolean, val text: String)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var onRecognized: ((String) -> Unit)? = null

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startListeningInternal()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            JarvisScreen(
                onSpeak = { speak(it) },
                onListen = { callback ->
                    onRecognized = callback
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED) {
                        startListeningInternal()
                    } else {
                        micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }
            )
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun startListeningInternal() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            onRecognized?.invoke("Speech recognition is not available on this device.")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                onRecognized?.invoke("I couldn't hear that. Please try again.")
            }
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!phrase.isNullOrBlank()) onRecognized?.invoke(phrase)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        speechRecognizer?.startListening(intent)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun JarvisScreen(onSpeak: (String) -> Unit, onListen: ((String) -> Unit) -> Unit) {
    val messages = remember {
        mutableStateListOf(ChatMessage(false, "Good day. J.A.R.V.I.S. systems are online. How may I assist you?"))
    }
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }

    fun respond(raw: String) {
        val question = raw.trim()
        if (question.isEmpty()) return
        messages.add(ChatMessage(true, question))
        val q = question.lowercase(Locale.getDefault())
        val answer = when {
            "time" in q -> "The current time is ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())}."
            "date" in q || "day" in q -> "Today is ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())}."
            "hello" in q || "hi" == q -> "Hello. All systems are operational."
            "your name" in q || "who are you" in q -> "I am J.A.R.V.I.S., your personal assistant interface."
            "help" in q || "what can you do" in q -> "I can chat, speak replies, and answer simple commands such as time and date."
            else -> "I have received your request. My basic offline assistant mode is active. Connect an AI service to enable open-ended answers."
        }
        messages.add(ChatMessage(false, answer))
        onSpeak(answer)
    }

    val infinite = rememberInfiniteTransition(label = "core")
    val pulse by infinite.animateFloat(
        initialValue = 0.88f, targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    Column(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF06182A), Bg, Color(0xFF02060D)))
        ).statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("J.A.R.V.I.S.", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("JUST A RATHER VERY INTELLIGENT SYSTEM", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("● SYSTEM ONLINE", color = Color(0xFF39F5A5), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text("ANDROID INTERFACE  v1.0", color = Muted, fontSize = 8.sp)
            }
        }

        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().height(185.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size((145 * pulse).dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xAA1CCBFF), Color(0x33118BFF), Color.Transparent)))
            )
            Box(Modifier.size(132.dp).border(2.dp, Cyan.copy(alpha = .8f), CircleShape)
                .border(1.dp, Color(0xFF176A9B), CircleShape).padding(9.dp)
                .border(1.dp, Cyan.copy(alpha = .6f), CircleShape), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("◈", color = Cyan, fontSize = 43.sp)
                    Text("J.A.R.V.I.S.", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(if (listening) "LISTENING..." else "CORE ACTIVE", color = Cyan, fontSize = 9.sp, letterSpacing = 2.sp)
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusTile("CORE", "ONLINE", Modifier.weight(1f))
            StatusTile("VOICE", "READY", Modifier.weight(1f))
            StatusTile("MODE", "DUAL", Modifier.weight(1f))
        }

        Spacer(Modifier.height(14.dp))
        Text("COMMUNICATION CHANNEL", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(14.dp))
                .background(Panel.copy(alpha = .8f)).border(1.dp, Color(0xFF145477), RoundedCornerShape(14.dp))
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (msg.fromUser) Alignment.End else Alignment.Start) {
                    Text(if (msg.fromUser) "YOU" else "J.A.R.V.I.S.", color = if (msg.fromUser) Color(0xFFB4D9EA) else Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(msg.text, color = Color.White, fontSize = 13.sp, modifier = Modifier
                        .padding(top = 3.dp).clip(RoundedCornerShape(10.dp))
                        .background(if (msg.fromUser) Color(0xFF10334A) else Color(0xFF0B2639))
                        .padding(10.dp))
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF0A2031)).border(1.dp, Color(0xFF17658A), RoundedCornerShape(24.dp))
                .padding(horizontal = 15.dp), contentAlignment = Alignment.CenterStart) {
                if (input.isEmpty()) Text("Type a command...", color = Muted.copy(alpha = .65f), fontSize = 13.sp)
                BasicTextField(value = input, onValueChange = { input = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 13.sp))
            }
            Button(onClick = { val text = input; input = ""; respond(text) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087DB0)),
                contentPadding = PaddingValues(horizontal = 15.dp), modifier = Modifier.height(48.dp)) {
                Text("SEND", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                listening = true
                onListen { spoken ->
                    listening = false
                    respond(spoken)
                }
            },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF063C5A)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("🎙  ${if (listening) "LISTENING — SPEAK NOW" else "TAP TO SPEAK"}", color = Color.White, letterSpacing = 1.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Text("STARK-INSPIRED PERSONAL ASSISTANT • LOCAL DEMO", color = Muted.copy(alpha = .55f), fontSize = 8.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp))
    }
}

@Composable
fun StatusTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(9.dp)).background(Color(0xFF092238))
        .border(1.dp, Color(0xFF155477), RoundedCornerShape(9.dp)).padding(9.dp)) {
        Text(label, color = Muted, fontSize = 8.sp, letterSpacing = 1.sp)
        Text(value, color = Color(0xFF48F0BC), fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
